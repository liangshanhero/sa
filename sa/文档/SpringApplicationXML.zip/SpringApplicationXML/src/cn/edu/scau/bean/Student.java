package cn.edu.scau.bean;

public class Student {
	int id;
	String name;
	String sex;
	Teacher tutor;
	public Teacher getTutor() {
		return tutor;
	}
	public void setTutor(Teacher tutor) {
		this.tutor = tutor;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}

}
