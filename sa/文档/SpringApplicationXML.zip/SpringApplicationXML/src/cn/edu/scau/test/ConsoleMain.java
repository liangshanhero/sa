package cn.edu.scau.test;

import org.springframework.context.ApplicationContext;

import cn.edu.scau.bean.Student;
import cn.edu.scau.util.SpringUtil;

public class ConsoleMain {
	public static void main(String[] args) {
		ApplicationContext ctx = SpringUtil.getApplicationContext();
		Student student = (Student) ctx.getBean("xxj");
		System.out.println(student.getName()+"的导师是"+student.getTutor().getName());
	}
}
